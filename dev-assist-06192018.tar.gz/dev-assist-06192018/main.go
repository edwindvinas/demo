// Copyright 2018 Google Inc. All rights reserved.
// Use of this source code is governed by the Apache 2.0
// license that can be found in the LICENSE file.

package main

import (
	//"fmt"
	"net/http"
	"io/ioutil"
	//"google.golang.org/appengine"
	"appengine"
	"encoding/json"
)

func init() {
	http.HandleFunc("/", handle)
	//appengine.Main()
}

func handle(w http.ResponseWriter, r *http.Request) {
	c := appengine.NewContext(r)
	//fmt.Fprintln(w, "Hello, world!")
	c.Infof("REQUEST: %v", r)
	bodyBytes, _ := ioutil.ReadAll(r.Body)
	c.Infof("JSON: %v", string(bodyBytes))
	data,_ := json.MarshalIndent(bodyBytes, "", "  ")
	w.Write(data)
}
