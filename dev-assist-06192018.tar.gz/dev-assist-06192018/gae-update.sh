#!/bin/sh
echo 'uploading & updating gae..'
gcloud --project=dev-assist-06192018 --account=edwin.d.vinas@gmail.com --verbosity=debug --quiet app deploy app.yaml
